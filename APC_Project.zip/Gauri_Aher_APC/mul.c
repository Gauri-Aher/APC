#include "header.h"
extern int n_flag;
Status multiplication(apc *head1, apc *tail1, apc *head2, apc *tail2, apc **head3, apc **tail3)
{
	int result = 0, count= 0, multiply = 0, carry = 0;		//declare the variables
	apc *temp1 = tail1;
	apc *temp2 = tail2;
	apc *result_head1 = NULL;
	apc *result_tail1 = NULL;
	apc *result_head2 = NULL;			//declare the temporary variables to traverse back
	apc *result_tail2 = NULL;
	while(temp2)								//run loop till reaching NULL
	{
		carry = 0;						//declare carry as 0 every time
		temp1 = tail1;							//update temp with tail everytime
		while(temp1)							//run loop till end of list
		{
			multiply =  carry;				//update mult with carry every time
			for(int i = 0; i < temp2->data; i++)
			{
				multiply = multiply + temp1->data;	//logic to find multipication
			}
			carry = multiply / 10;				//find carry and update the mult variable
			multiply = multiply % 10;
			if(count == 0)
			{
				add_res(&result_head1, &result_tail1, multiply);//for first time add result in head1
			}
			else
			{
				add_res(&result_head2, &result_tail2, multiply);//remaining all times update in head2
			}
			temp1 = temp1->prev;										//traverse through the list
		}
		if(carry > 0 && count > 0)
		{
			add_res(&result_head2, &result_tail2, carry); //if carry is there add carry also
		}
		if(count == 0)
		{
			if(carry > 0)
			{
				add_res(&result_head1, &result_tail1, carry);		//add carry
			}
			add_res(&result_head1, &result_tail1, 0);			//add 0 for next iteration
		}
		if(count >= 1)
		{
			for(int i = 1; i <= count; i++)
			{
				insert_last(&result_head2, &result_tail2); //add 0 at last for making nodes equal
			}
			if(count%2 == 1)
			{
				//based on count add result in one node
				addition(result_head1, result_tail1, result_head2, result_tail2, head3, tail3);
				free_node(&result_head2, &result_tail2);	 //free nodes after adding results
				free_node(&result_head1, &result_tail1);
				add_res(head3, tail3, 0);
			}
			else
			{
				//based on count add result in another node
				addition(*head3, *tail3, result_head2, result_tail2, &result_head1, &result_tail1);
				free_node(head3, tail3);
				free_node(&result_head2, &result_tail2);	//free the nodes after adding results
				add_res(&result_head1, &result_tail1, 0);
			}
		}
		temp2 = temp2->prev;
		count++;
	}
	if(count % 2)
	{
		free_first(&result_head1);	//free the 0 at starting and print result and add negative sign
		if(n_flag)
		{
			add_res(&result_head1, &result_tail1, '-');
		}
		print_res(&result_head1, &result_tail1);
	}
	else
	{
		free_first(head3);	//free 0 and print result based on flag add negative sign
		if(n_flag)
		{
			add_res(head3, tail3, '-');
		}
		print_res(head3, tail3);
	}
	free_node(&result_head1, &result_tail1);
	free_node(&result_head2, &result_tail2);
	return success;
}
/*Insert at last function*/
void insert_last(apc **head, apc **tail)
{
	apc *new = malloc(sizeof(apc));
	if(new == NULL)
	{
		printf("Memory not allocated\n");
	}
	else
	{
		new->data = 0;
		new->prev = *tail;
		(*tail)->next = new;
		new->next = NULL;
		*tail = new;
	}
}

/*Function to free the first node*/
void free_first(apc **head)
{
	apc *temp = *head;
	*head = (*head)->next;
	(*head)->prev = NULL;
	free(temp);
}
