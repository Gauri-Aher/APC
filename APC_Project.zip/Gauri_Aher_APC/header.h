#ifndef HEADER_FILE
#define HEADER_FILE

#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<ctype.h>

typedef struct node
{
	struct node *prev;
	int data;
	struct node *next;
}apc;

typedef enum 
{
	failure,
	success,
}Status;

Status insert_args(apc **head1, apc** tail1, apc** head2, apc** tail2, char* argv1, char* argv2);
Status insert_at_last(apc **head1, apc **tail1, char *data);
Status addition(apc *head1, apc *tail1, apc *head2, apc *tail2, apc **head3, apc **tail3);
Status add_res(apc **head3, apc **tail3, int sum);
Status free_all(apc **head1, apc **tail1, apc **head2, apc **tail2, apc **head3, apc **tail3);
Status substraction(apc *head1, apc *tail1, apc *head2, apc *tail2, apc **head3, apc **tail3);
Status division(apc *head1, apc *tail1, apc *head2, apc *tail2, apc **head3, apc **tail3);
Status multiplication(apc *head1, apc *tail1, apc *head2, apc *tail2, apc **head3, apc **tail3);
void free_node(apc **head, apc **tail);
int find_bigger(apc **head1, apc **head2);
void print_res(apc **head, apc **tail);
int find_len(char *argv);
int check_node(apc **head1, apc **head2);
void insert_last(apc **head, apc **tail);
void insert_first(apc **head, apc **tail, int data);
void free_first(apc **head);

#endif
