#include"header.h"

int n_flag = 0;

int main(int argc, char * argv[])
{
	/*Error handling to pass the valid arguments*/
	if(argc < 4)
	{
		fprintf(stderr,"Give valid Arguments\n");
		printf("i.e. result.exe operand operator operand\n");
		return 0;
	}

	/*Validation for the operator*/
	if((strcmp(argv[2], "+") != 0) && (strcmp(argv[2], "-") != 0) && (strcmp(argv[2], "x") != 0) && (strcmp(argv[2], "/") != 0))
	{
		fprintf(stderr,"Give valid arguments\n");
		return 0;
	}

	/*Declare pointers for the data and result*/
	apc *head1 = NULL;
	apc *tail1 = NULL;
	apc *head2 = NULL;
	apc *tail2 = NULL;
	apc *head3 = NULL;
	apc *tail3 = NULL;
	char ch = argv[2][0];

	/*Insert arguments into lists*/
	if(insert_args(&head1, &tail1, &head2, &tail2, argv[1], argv[3]) == success)
	{
		printf("Inserted successful\n");
	}
	else
	{
		printf("Insertion failed\n");
		return 0;
	}

	int diff;
	if(ch != 'x')
	{
		/*Find length of the both arguments excluding sign*/
		int l1 = find_len(argv[1]);
		int l2 = find_len(argv[3]);
		/*Based on difference add 0's to make lists equal*/
		if(l1 > l2)
		{
			diff = l1 - l2;
			for(int i = 0; i< diff; i++)
			{
				add_res(&head2, &tail2, 0);			//run loop to add zeroes
			}
		}
		else if(l2 > l1)
		{
			diff = l2 - l1;
			for(int i = 0; i < diff; i++)
			{
				add_res(&head1, &tail1, 0);
			}
		}
	}
	/*Find big number among two lists*/
	int bigger_num = find_bigger(&head1, &head2);
	if(ch == '+')											//if operator is +
	{
		if(argv[1][0] == '-' && argv[3][0] == '-')			//if both signs are negative add sign bit
		{
			n_flag = 1;
		}
		else if(argv[bigger_num][0] == '-')				//if big num has - add negative sign
		{
			n_flag = 1;
		}
	}
	else if(ch == '-')					//if ch is -
	{
		if(bigger_num == 1 && argv[1][0] == '-') 		//if both arguments are - enable negative flag 
		{
			n_flag = 1;
		}
		else if(argv[3][0] != '-' && bigger_num != 1) //if second argument has - and big number is not 1 enable negative flag
		{
			n_flag = 1;
		}
	}
	else if( ch == '/' || ch == 'x')
	{
		if( argv[1][0] == '-' && argv[3][0] != '-')
		{
			n_flag = 1;
		}
		else if( argv[1][0] != '-' && argv[3][0] == '-')
		{
			n_flag = 1;
		}
	}
	
	/*Choose correct operator based on signs given for arguments*/
	if(argv[2][0] == '+')
	{
		if((argv[1][0] != '-' && argv[3][0] == '-') || (argv[1][0] == '-' && argv[3][0] != '-'))
		{
			ch = '-';
		}
		else
		{
			ch = '+';
		}
	}
	else if(argv[2][0] == '-')
	{
		if((argv[1][0] == '-' && argv[3][0] != '-') || (argv[1][0] != '-' && argv[3][0] == '-'))
		{
			ch = '+';
		}
		else
		{
			ch = '-';
		}
	}
/*Switch case based on operator*/
	switch(ch)
	{
		case '+':
		/*Call addition Function*/
			if(addition(head1, tail1, head2, tail2, &head3, &tail3) == success)
			{
				printf("Addition Done successfully\n");
			}
			else
			{
				printf("Addition failed\n");
			}
			break;

		case '-':
		/*Call Subtraction Function*/
			if(bigger_num == 1)
			{
				substraction(head1,tail1,head2,tail2,&head3,&tail3) == success;
			}
			else if( bigger_num == 3)
			{
				substraction(head2, tail2, head1, tail1, &head3, &tail3);
			}
			else
			{
				printf("Result is 0\n");
				return 0;
			}
			break;

		case '/':
		/*Call division Function*/
			if(bigger_num == 3)
			{
			     printf("Result is 0\n");//if denominator is big number than numerator the result is 0
				return 0;
			}
			else
			{
				division(head1, tail1, head2, tail2, &head3, &tail3);
			}
			break;

		case 'x':
		/*Call Multilication Function*/
			if(multiplication(head1, tail1, head2, tail2, &head3, &tail3) == success)
			{
				printf("Multiplication Done successfully \n");
			}
			else
			{
				printf("Multiplication failed\n");
			}
			break;
	}
	/*Based on negative flag add sign for result*/
	if(n_flag == 1)
	{
		add_res(&head3, &tail3, '-');
	}
	if(ch != 'x' && ch != '/')
	{
		print_res(&head3, &tail3);
	}
	/*Free all the nodes after the operation*/
	free_all(&head1, &tail1, &head2, &tail2, &head3, &tail3);
	return 0;
}


