#include "header.h"

Status insert_args(apc **head1, apc **tail1, apc **head2, apc **tail2, char* argv1, char* argv2)
{
	insert_at_last(head1, tail1, argv1);		//Function calls to insert the arguments
	insert_at_last(head2, tail2, argv2);
}

Status insert_at_last(apc **head, apc **tail, char* argv)		//Perform insert at last function
{
	for(int i = 0; i < strlen(argv); i++)				//Till end of argument vector run loop
	{
		apc* new = malloc(sizeof(apc));					//Allocate memory dynamically
		if(new == NULL)
		{
			printf("Memory not allocated\n");		//if memory not allocated return failure
			return failure;
		}
		if(argv[i] != '-' && argv[i] != '+')			//If there were any signs ignore
		{
			new->data = argv[i] - 48;										//convert character into decimal
			if((new->data >= 0) && (new->data <= 9))		//if it is between 0 and 9
			{
				new->prev = NULL;
				new->next = NULL;										//update link parts with NULL
				if(*head == NULL)
				{
					*head = new; //if list is empty directly update the list with new address
					*tail = new;
				}
				else
				{
					new->prev = *tail;	//if not update the new prev with tail
					(*tail)->next = new;	//update tail next with new 
					*tail = new;		//at last update tail with new
				}
			}
		}
	}
	return success;
}

/*Function to free all nodes*/
Status free_all(apc **head1, apc **tail1, apc **head2, apc **tail2, apc **head3, apc **tail3)
{
	free_node(head1,tail1);
	free_node(head2,tail2);			//call function to free each node
	free_node(head3,tail3);
}

/*Free each node*/
void free_node(apc **head, apc **tail)
{
	apc* temp = (*head);
	apc* backup = NULL;

	while(temp != NULL)				//run loop till end of list and free each node
	{
		backup = temp->next;				//update back up with next address
		free(temp);								//free temp 
		temp = backup;					//and then update temp with back up
	}
	*head = NULL;						//update head and tail with NULL
	*tail = NULL;
}
/*Function to find bigger based on lists*/
int find_bigger(apc **head1, apc **head2)
{
	apc *temp = *head1;
	apc *temp2 = *head2;

	while(temp && temp2)
	{
		if(temp->data > temp2->data)
		{
			return 1;
		}
		else if(temp2->data > temp->data)
		{
			return 3;
		}
		temp = temp->next;
		temp2 = temp2->next;

	}
	return 0;
}


/*Print result function to print data of node*/
void print_res(apc **head, apc **tail)
{
	printf("Result is: ");
	apc* temp = *head;
	while(temp != NULL)
	{
		if(temp->data == '-')
		{
			printf("%c",'-');
		}
		else
		{
			printf("%d",temp->data);
		}
		temp = temp->next;
	}
	printf("\n");
}

/*Find length of argument ignoring the signs*/
int find_len(char* argv)
{
	int i = 0;
	int count = 0;
	while(argv[i] != '\0')
	{
		if(argv[i] == '-' || argv[i] == '+')
		{
			i++;
			continue;
		}
		else
		{
			count++;
			i++;
		}
	}
	return count;
}