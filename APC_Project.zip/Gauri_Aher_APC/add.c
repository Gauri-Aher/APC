#include "header.h"
Status addition(apc *head1, apc *tail1, apc *head2, apc *tail2, apc **head3, apc **tail3){
	int carry=0, sum=0, res=0, car=0;					//initially declare all variables

	apc *temp1 = tail1;
	apc *temp2 = tail2;

	while(temp1 != NULL || temp2 != NULL)
	{
		if((temp1->prev == NULL) && (temp2->prev != NULL))
		{
			add_res(&head1,&tail1,0);	//if both linked lists are not same add 0s at starting
		}
		else if((temp2->prev == NULL) && (temp1->prev != NULL))
		{
			add_res(&head2,&tail2,0);
		}
		res = (temp1->data) + (temp2->data) + carry;				//logic to find the addition
		car = res / 10;												//find carry to update in next iteration
		res = res % 10;												//update result value
		sum =  res;

		add_res(head3, tail3, sum);				//add sum in list
		temp1 = temp1->prev;
		temp2 = temp2->prev;
		carry = car;
	}

	if(carry != 0)
	{
		add_res(head3, tail3, carry);			//at last if carry is not 0 add carry also
	}

	return success;
}


Status add_res(apc **head3, apc **tail3, int sum)			//function to insert at first
{
	apc *new = malloc(sizeof(apc));							//allocate memory dynamically
	if(new == NULL)
	{
		printf("Memory not allocated\n");					//if memory is not allocated return failure
		return failure;
	}
	new->data = sum;														//add data part with sum
	new->prev = NULL;
	new->next = NULL;														//update link parts with NULL
	if(*head3 == NULL)
	{	
		*head3 = new;													    //if list is empty update head and tail
		*tail3 = new;
	}
	else
	{
		new->next = *head3;													//update next part with head address
		(*head3)->prev = new;												
		*head3 = new;														//update head3 with new
	}
	return success;															
}


